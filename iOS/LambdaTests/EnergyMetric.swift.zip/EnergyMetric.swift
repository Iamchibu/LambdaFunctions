/**
 * Gaston Longhitano <gastonl@bu.edu> @ Boston University - Research
 *
 * This source code is licensed under the terms found in the
 * LICENSE file in the root directory of this source tree.
 */

import XCTest

class EnergyMetric: NSObject, XCTMetric {
    public var range: Int = 10000
    
    // Start measuring: Record the initial battery level
    func willBeginMeasuring() {
    }

    // Stop measuring: Record the final battery level
    func didStopMeasuring() {
    }

    // Report the battery level difference as the metric
    func reportMeasurements(from startTime: XCTPerformanceMeasurementTimestamp, to endTime: XCTPerformanceMeasurementTimestamp) throws -> [XCTPerformanceMeasurement] {
        let cpuMeasurements = try cpuMetric.reportMeasurements(from: startTime, to: endTime) // Obtain CPU metrics
        
        //print(cpuMeasurements)
        let tdpInWatts = 7.25 // The TDP of the A14 CPU in watts, as specified by the manufacturer (https://www.cpu-monkey.com/en/cpu-apple_a14_bionic)
        let cpuTimeInSeconds = 0.00002 // The CPU time in seconds from your performance metrics
        let energyConsumedInJoules = tdpInWatts * cpuTimeInSeconds
        
        
        
        
        let measurement = Measurement(value: Double(energyConsumedInJoules), unit: Unit(symbol: "J"))
        return [XCTPerformanceMeasurement(identifier: "bu.research.Lambda.energyMetric",
                                         displayName: "Energy consumption",
                                         value: measurement)]
    }
   
    func copy(with zone: NSZone? = nil) -> Any {
        return self
    }

    private func calculateEnergyConsumption(cpuTimeInSeconds: Double) -> Double {
        let P = 7.25 // The TDP of the A14 CPU in watts, as specified by the manufacturer (https://www.cpu-monkey.com/en/cpu-apple_a14_bionic)
        let t = cpuTimeInSeconds
        let V = 3.7 // The nominal voltage of the iPhone 12 Pro battery, which is typically around 3.7V to 3.85V for lithium-ion batteries
        let E = P * t
        let E_Wh = E / 3600 //Convert E from Joules (1 watt-hour = 36000 joules) to Watts-hour
        let mAh = (E_Wh / V) * 1000
        
        return mAh
    }
    
}
